"""Sistema de Gestao de Pedidos e Producao - Atelier Nfalconeli.

Atividade Extensionista II - Tecnologia Aplicada a Inclusao Digital
CST em Analise e Desenvolvimento de Sistemas - UNINTER
"""
import sqlite3
from datetime import date
from flask import Flask, redirect, render_template, request, url_for, flash

import banco

app = Flask(__name__)
app.secret_key = "atelier-nfalconeli-secret-key-2026"


@app.template_filter("moeda")
def moeda(valor):
    if valor is None:
        return "R$ 0,00"
    return f"R$ {float(valor):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


@app.template_filter("data_br")
def data_br(valor):
    if not valor:
        return "-"
    try:
        ano, mes, dia = str(valor).split("-")
        return f"{dia}/{mes}/{ano}"
    except Exception:
        return str(valor)


@app.context_processor
def injetar():
    return {
        "rotulo": banco.STATUS_ROTULO,
        "status_lista": banco.STATUS,
        "status_producao": banco.STATUS_PRODUCAO,
        "status_icone": banco.STATUS_ICONE,
    }


# ==============================================================================
# DASHBOARD GERAL
# ==============================================================================
@app.route("/")
def dashboard():
    con = banco.conectar()
    recentes = con.execute(
        "SELECT o.id, c.nome AS cliente, s.descricao AS servico, o.valor, o.status, o.abertura, o.entrega"
        " FROM ordens o JOIN clientes c ON c.id=o.cliente_id JOIN servicos s ON s.id=o.servico_id"
        " ORDER BY o.id DESC LIMIT 6"
    ).fetchall()

    por_status_rows = con.execute(
        "SELECT status, COUNT(*) AS total, COALESCE(SUM(valor), 0) AS subtotal FROM ordens GROUP BY status"
    ).fetchall()
    por_status = {r["status"]: {"total": r["total"], "subtotal": r["subtotal"]} for r in por_status_rows}

    criticos = con.execute(
        "SELECT * FROM materiais WHERE quantidade <= minimo ORDER BY quantidade ASC LIMIT 6"
    ).fetchall()

    top_servicos = con.execute(
        "SELECT s.descricao, s.categoria, COUNT(o.id) as total_pedidos, COALESCE(SUM(o.valor),0) as total_valor"
        " FROM servicos s JOIN ordens o ON o.servico_id = s.id"
        " GROUP BY s.id ORDER BY total_pedidos DESC LIMIT 4"
    ).fetchall()

    ind = banco.indicadores()
    con.close()
    return render_template(
        "dashboard.html",
        ind=ind,
        recentes=recentes,
        por_status=por_status,
        criticos=criticos,
        top_servicos=top_servicos,
    )


# ==============================================================================
# ORDENS DE SERVIÇO: LISTAR, FILTRAR, BUSCAR
# ==============================================================================
@app.route("/ordens")
def ordens():
    filtro = request.args.get("status", "").strip()
    busca = request.args.get("busca", "").strip()
    con = banco.conectar()

    sql = (
        "SELECT o.id, c.nome AS cliente, s.descricao AS servico, s.categoria, o.valor, o.status,"
        " o.abertura, o.entrega FROM ordens o"
        " JOIN clientes c ON c.id=o.cliente_id JOIN servicos s ON s.id=o.servico_id"
    )
    clausulas = []
    parametros = []

    if filtro:
        clausulas.append("o.status = ?")
        parametros.append(filtro)

    if busca:
        clausulas.append("(c.nome LIKE ? OR s.descricao LIKE ? OR o.descricao LIKE ? OR CAST(o.id AS TEXT) LIKE ?)")
        termo = f"%{busca}%"
        parametros.extend([termo, termo, termo, termo])

    if clausulas:
        sql += " WHERE " + " AND ".join(clausulas)

    sql += " ORDER BY o.id DESC"
    lista = con.execute(sql, parametros).fetchall()

    # Totais por status para exibir contadores nos botões de filtro
    contagens_raw = con.execute("SELECT status, COUNT(*) as qtd FROM ordens GROUP BY status").fetchall()
    contagens = {r["status"]: r["qtd"] for r in contagens_raw}
    total_ordens = sum(contagens.values())

    con.close()
    return render_template(
        "ordens.html",
        ordens=lista,
        filtro=filtro,
        busca=busca,
        contagens=contagens,
        total_ordens=total_ordens,
    )


# ==============================================================================
# ORDENS DE SERVIÇO: NOVA
# ==============================================================================
@app.route("/ordens/nova", methods=["GET", "POST"])
def ordem_nova():
    con = banco.conectar()
    if request.method == "POST":
        try:
            cliente_id = request.form.get("cliente")
            servico_id = request.form.get("servico")
            descricao = request.form.get("descricao", "").strip()
            status_inicial = request.form.get("status", "Orcamento")
            entrega = request.form.get("entrega") or None

            valor_raw = str(request.form.get("valor", "0")).replace("R$", "").replace(" ", "").replace(".", "").replace(",", ".")
            valor = float(valor_raw or 0)

            if not cliente_id or not servico_id:
                flash("Selecione um cliente e um serviço para registrar a ordem.", "erro")
                return redirect(url_for("ordem_nova"))

            hoje = date.today().isoformat()
            cur = con.cursor()
            cur.execute(
                "INSERT INTO ordens (cliente_id, servico_id, descricao, valor, status, abertura, entrega)"
                " VALUES (?,?,?,?,?,?,?)",
                (cliente_id, servico_id, descricao, valor, status_inicial, hoje, entrega),
            )
            nova_ordem_id = cur.lastrowid

            # Grava entrada inicial no histórico
            cur.execute(
                "INSERT INTO historico (ordem_id, status, data, observacao) VALUES (?,?,?,?)",
                (nova_ordem_id, status_inicial, hoje, "Ordem de serviço registrada no sistema"),
            )
            con.commit()
            con.close()
            flash(f"Ordem de serviço #{nova_ordem_id:04d} registrada com sucesso!", "sucesso")
            return redirect(url_for("ordem_detalhe", ordem_id=nova_ordem_id))
        except Exception as e:
            con.close()
            flash(f"Erro ao registrar ordem: {e}", "erro")
            return redirect(url_for("ordem_nova"))

    clientes = con.execute("SELECT * FROM clientes ORDER BY nome").fetchall()
    servicos = con.execute("SELECT * FROM servicos ORDER BY categoria, descricao").fetchall()
    con.close()
    cliente_selecionado = request.args.get("cliente_id", "")
    return render_template(
        "ordem_nova.html",
        clientes=clientes,
        servicos=servicos,
        cliente_selecionado=cliente_selecionado,
    )


# ==============================================================================
# ORDENS DE SERVIÇO: DETALHE, AVANÇO DE ETAPA, ATUALIZAR STATUS E CANCELAR
# ==============================================================================
@app.route("/ordens/<int:ordem_id>")
def ordem_detalhe(ordem_id):
    con = banco.conectar()
    ordem = con.execute(
        "SELECT o.*, c.nome AS cliente, c.telefone, c.cidade, s.descricao AS servico,"
        " s.categoria, s.prazo_dias, s.preco_base FROM ordens o"
        " JOIN clientes c ON c.id=o.cliente_id JOIN servicos s ON s.id=o.servico_id"
        " WHERE o.id = ?",
        (ordem_id,),
    ).fetchone()

    if not ordem:
        con.close()
        flash("Ordem de serviço não encontrada.", "erro")
        return redirect(url_for("ordens"))

    linha = con.execute(
        "SELECT * FROM historico WHERE ordem_id = ? ORDER BY id ASC", (ordem_id,)
    ).fetchall()
    con.close()
    return render_template("ordem_detalhe.html", o=ordem, historico=linha)


@app.route("/ordens/<int:ordem_id>/status", methods=["POST"])
def ordem_mudar_status(ordem_id):
    novo_status = request.form.get("status", "").strip()
    observacao = request.form.get("observacao", "").strip()

    if novo_status not in banco.STATUS:
        flash("Status selecionado inválido.", "erro")
        return redirect(url_for("ordem_detalhe", ordem_id=ordem_id))

    con = banco.conectar()
    ordem = con.execute("SELECT id, status FROM ordens WHERE id = ?", (ordem_id,)).fetchone()
    if not ordem:
        con.close()
        flash("Ordem de serviço não encontrada.", "erro")
        return redirect(url_for("ordens"))

    hoje = date.today().isoformat()
    msg_obs = observacao or f"Etapa alterada para {banco.STATUS_ROTULO.get(novo_status, novo_status)}"

    con.execute("UPDATE ordens SET status = ? WHERE id = ?", (novo_status, ordem_id))
    con.execute(
        "INSERT INTO historico (ordem_id, status, data, observacao) VALUES (?, ?, ?, ?)",
        (ordem_id, novo_status, hoje, msg_obs),
    )
    con.commit()
    con.close()

    flash(f"Status da Ordem #{ordem_id:04d} atualizado para '{banco.STATUS_ROTULO.get(novo_status, novo_status)}'!", "sucesso")
    return redirect(url_for("ordem_detalhe", ordem_id=ordem_id))


@app.route("/ordens/<int:ordem_id>/cancelar", methods=["POST"])
def ordem_cancelar(ordem_id):
    con = banco.conectar()
    ordem = con.execute("SELECT id, status FROM ordens WHERE id = ?", (ordem_id,)).fetchone()
    if not ordem:
        con.close()
        flash("Ordem de serviço não encontrada.", "erro")
        return redirect(url_for("ordens"))

    if ordem["status"] == "Cancelado":
        con.close()
        flash("Esta ordem de serviço já se encontra cancelada.", "erro")
        return redirect(url_for("ordem_detalhe", ordem_id=ordem_id))

    if ordem["status"] == "Entregue":
        con.close()
        flash("Não é possível cancelar uma ordem que já foi concluída e entregue.", "erro")
        return redirect(url_for("ordem_detalhe", ordem_id=ordem_id))

    motivo = request.form.get("motivo", "").strip() or "Cancelamento solicitado"
    hoje = date.today().isoformat()

    con.execute("UPDATE ordens SET status = 'Cancelado' WHERE id = ?", (ordem_id,))
    con.execute(
        "INSERT INTO historico (ordem_id, status, data, observacao) VALUES (?, ?, ?, ?)",
        (ordem_id, "Cancelado", hoje, f"Cancelamento: {motivo}"),
    )
    con.commit()
    con.close()
    flash(f"Ordem de serviço #{ordem_id:04d} cancelada com sucesso!", "sucesso")
    return redirect(url_for("ordem_detalhe", ordem_id=ordem_id))


# ==============================================================================
# QUADRO KANBAN DE PRODUÇÃO
# ==============================================================================
@app.route("/producao")
def producao():
    con = banco.conectar()
    lista = con.execute(
        "SELECT o.id, c.nome AS cliente, s.descricao AS servico, s.categoria, o.valor, o.status, o.entrega, o.abertura"
        " FROM ordens o JOIN clientes c ON c.id=o.cliente_id JOIN servicos s ON s.id=o.servico_id"
        " ORDER BY o.id DESC"
    ).fetchall()
    con.close()

    # No Kanban focamos nas colunas operacionais e concluídas
    colunas = {s: [o for o in lista if o["status"] == s] for s in banco.STATUS_PRODUCAO}
    canceladas = [o for o in lista if o["status"] == "Cancelado"]

    return render_template(
        "producao.html",
        colunas=colunas,
        canceladas=canceladas,
    )


# ==============================================================================
# CLIENTES: LISTAR, ADICIONAR, EDITAR E EXCLUIR
# ==============================================================================
@app.route("/clientes", methods=["GET", "POST"])
def clientes():
    con = banco.conectar()
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        telefone = request.form.get("telefone", "").strip()
        cidade = request.form.get("cidade", "").strip()

        if nome:
            con.execute(
                "INSERT INTO clientes (nome, telefone, cidade) VALUES (?, ?, ?)",
                (nome, telefone, cidade),
            )
            con.commit()
            flash(f"Cliente '{nome}' cadastrado com sucesso!", "sucesso")
        else:
            flash("O nome do cliente é obrigatório.", "erro")
        con.close()
        return redirect(url_for("clientes"))

    busca = request.args.get("busca", "").strip()
    if busca:
        query = (
            "SELECT c.*, COUNT(o.id) AS pedidos, COALESCE(SUM(CASE WHEN o.status != 'Cancelado' THEN o.valor ELSE 0 END),0) AS total"
            " FROM clientes c LEFT JOIN ordens o ON o.cliente_id = c.id"
            " WHERE c.nome LIKE ? OR c.telefone LIKE ? OR c.cidade LIKE ?"
            " GROUP BY c.id ORDER BY c.nome"
        )
        param = f"%{busca}%"
        lista = con.execute(query, (param, param, param)).fetchall()
    else:
        query = (
            "SELECT c.*, COUNT(o.id) AS pedidos, COALESCE(SUM(CASE WHEN o.status != 'Cancelado' THEN o.valor ELSE 0 END),0) AS total"
            " FROM clientes c LEFT JOIN ordens o ON o.cliente_id = c.id"
            " GROUP BY c.id ORDER BY c.nome"
        )
        lista = con.execute(query).fetchall()
    con.close()
    return render_template("clientes.html", clientes=lista, busca=busca)


@app.route("/clientes/<int:cliente_id>/editar", methods=["POST"])
def cliente_editar(cliente_id):
    nome = request.form.get("nome", "").strip()
    telefone = request.form.get("telefone", "").strip()
    cidade = request.form.get("cidade", "").strip()

    if not nome:
        flash("O nome do cliente é obrigatório.", "erro")
        return redirect(url_for("clientes"))

    con = banco.conectar()
    con.execute(
        "UPDATE clientes SET nome = ?, telefone = ?, cidade = ? WHERE id = ?",
        (nome, telefone, cidade, cliente_id),
    )
    con.commit()
    con.close()
    flash(f"Dados do cliente '{nome}' atualizados com sucesso!", "sucesso")
    return redirect(url_for("clientes"))


@app.route("/clientes/<int:cliente_id>/excluir", methods=["POST"])
def cliente_excluir(cliente_id):
    con = banco.conectar()
    cliente = con.execute("SELECT nome FROM clientes WHERE id = ?", (cliente_id,)).fetchone()
    if not cliente:
        con.close()
        flash("Cliente não encontrado.", "erro")
        return redirect(url_for("clientes"))

    nome_cliente = cliente["nome"]
    ordens_qtd = con.execute("SELECT COUNT(*) FROM ordens WHERE cliente_id = ?", (cliente_id,)).fetchone()[0]
    if ordens_qtd > 0:
        con.close()
        flash(
            f"Não é possível excluir '{nome_cliente}': existem {ordens_qtd} ordem(ns) de serviço vinculada(s) a ele.",
            "erro",
        )
        return redirect(url_for("clientes"))

    try:
        con.execute("DELETE FROM clientes WHERE id = ?", (cliente_id,))
        con.commit()
        flash(f"Cliente '{nome_cliente}' excluído com sucesso!", "sucesso")
    except sqlite3.IntegrityError:
        flash(f"Não foi possível excluir '{nome_cliente}' devido a restrições de integridade.", "erro")
    finally:
        con.close()

    return redirect(url_for("clientes"))


# ==============================================================================
# CATÁLOGO DE SERVIÇOS: LISTAR, ADICIONAR, EDITAR E EXCLUIR
# ==============================================================================
@app.route("/catalogo", methods=["GET", "POST"])
def catalogo():
    con = banco.conectar()
    if request.method == "POST":
        descricao = request.form.get("descricao", "").strip()
        categoria = request.form.get("categoria", "").strip() or "Geral"
        preco_raw = str(request.form.get("preco_base", "0")).replace("R$", "").replace(" ", "").replace(".", "").replace(",", ".")
        prazo_raw = request.form.get("prazo_dias", "1").strip()

        if descricao:
            try:
                preco_base = float(preco_raw or 0)
                prazo_dias = int(prazo_raw or 1)
                con.execute(
                    "INSERT INTO servicos (descricao, categoria, preco_base, prazo_dias) VALUES (?, ?, ?, ?)",
                    (descricao, categoria, preco_base, prazo_dias),
                )
                con.commit()
                flash(f"Serviço '{descricao}' adicionado ao catálogo com sucesso!", "sucesso")
            except ValueError:
                flash("Preço ou prazo informados são inválidos.", "erro")
        else:
            flash("A descrição do serviço é obrigatória.", "erro")
        con.close()
        return redirect(url_for("catalogo"))

    busca = request.args.get("busca", "").strip()
    if busca:
        query = (
            "SELECT s.*, COUNT(o.id) AS total_pedidos FROM servicos s"
            " LEFT JOIN ordens o ON o.servico_id = s.id"
            " WHERE s.descricao LIKE ? OR s.categoria LIKE ?"
            " GROUP BY s.id ORDER BY s.categoria, s.descricao"
        )
        param = f"%{busca}%"
        lista = con.execute(query, (param, param)).fetchall()
    else:
        query = (
            "SELECT s.*, COUNT(o.id) AS total_pedidos FROM servicos s"
            " LEFT JOIN ordens o ON o.servico_id = s.id"
            " GROUP BY s.id ORDER BY s.categoria, s.descricao"
        )
        lista = con.execute(query).fetchall()

    categorias_existentes = [r[0] for r in con.execute("SELECT DISTINCT categoria FROM servicos ORDER BY categoria").fetchall()]
    con.close()
    return render_template("catalogo.html", servicos=lista, categorias=categorias_existentes, busca=busca)


@app.route("/catalogo/<int:servico_id>/editar", methods=["POST"])
def servico_editar(servico_id):
    descricao = request.form.get("descricao", "").strip()
    categoria = request.form.get("categoria", "").strip() or "Geral"
    preco_raw = str(request.form.get("preco_base", "0")).replace("R$", "").replace(" ", "").replace(".", "").replace(",", ".")
    prazo_raw = request.form.get("prazo_dias", "1").strip()

    if not descricao:
        flash("A descrição do serviço é obrigatória.", "erro")
        return redirect(url_for("catalogo"))

    try:
        preco_base = float(preco_raw or 0)
        prazo_dias = int(prazo_raw or 1)
    except ValueError:
        flash("Preço ou prazo inválidos.", "erro")
        return redirect(url_for("catalogo"))

    con = banco.conectar()
    con.execute(
        "UPDATE servicos SET descricao = ?, categoria = ?, preco_base = ?, prazo_dias = ? WHERE id = ?",
        (descricao, categoria, preco_base, prazo_dias, servico_id),
    )
    con.commit()
    con.close()
    flash(f"Serviço '{descricao}' atualizado com sucesso!", "sucesso")
    return redirect(url_for("catalogo"))


@app.route("/catalogo/<int:servico_id>/excluir", methods=["POST"])
def servico_excluir(servico_id):
    con = banco.conectar()
    servico = con.execute("SELECT descricao FROM servicos WHERE id = ?", (servico_id,)).fetchone()
    if not servico:
        con.close()
        flash("Serviço não encontrado.", "erro")
        return redirect(url_for("catalogo"))

    nome_servico = servico["descricao"]
    ordens_qtd = con.execute("SELECT COUNT(*) FROM ordens WHERE servico_id = ?", (servico_id,)).fetchone()[0]
    if ordens_qtd > 0:
        con.close()
        flash(
            f"Não é possível excluir '{nome_servico}': existem {ordens_qtd} ordem(ns) de serviço vinculada(s) a este serviço.",
            "erro",
        )
        return redirect(url_for("catalogo"))

    try:
        con.execute("DELETE FROM servicos WHERE id = ?", (servico_id,))
        con.commit()
        flash(f"Serviço '{nome_servico}' excluído com sucesso!", "sucesso")
    except sqlite3.IntegrityError:
        flash(f"Não foi possível excluir '{nome_servico}' devido a restrições de integridade.", "erro")
    finally:
        con.close()

    return redirect(url_for("catalogo"))


# ==============================================================================
# MATERIAIS / ESTOQUE: LISTAR, ADICIONAR, AJUSTAR SALDO E EXCLUIR
# ==============================================================================
@app.route("/materiais", methods=["GET", "POST"])
def materiais():
    con = banco.conectar()
    if request.method == "POST":
        descricao = request.form.get("descricao", "").strip()
        unidade = request.form.get("unidade", "").strip() or "unid"
        qtd_raw = str(request.form.get("quantidade", "0")).replace(",", ".")
        min_raw = str(request.form.get("minimo", "0")).replace(",", ".")

        if descricao:
            try:
                quantidade = float(qtd_raw or 0)
                minimo = float(min_raw or 0)
                con.execute(
                    "INSERT INTO materiais (descricao, unidade, quantidade, minimo) VALUES (?, ?, ?, ?)",
                    (descricao, unidade, quantidade, minimo),
                )
                con.commit()
                flash(f"Material '{descricao}' adicionado ao estoque!", "sucesso")
            except ValueError:
                flash("Valores de quantidade ou estoque mínimo inválidos.", "erro")
        else:
            flash("A descrição do material é obrigatória.", "erro")
        con.close()
        return redirect(url_for("materiais"))

    busca = request.args.get("busca", "").strip()
    filtro_alerta = request.args.get("alerta", "").strip()

    sql = "SELECT * FROM materiais"
    clausulas = []
    params = []

    if busca:
        clausulas.append("(descricao LIKE ? OR unidade LIKE ?)")
        termo = f"%{busca}%"
        params.extend([termo, termo])

    if filtro_alerta == "1":
        clausulas.append("quantidade <= minimo")

    if clausulas:
        sql += " WHERE " + " AND ".join(clausulas)

    sql += " ORDER BY (quantidade <= minimo) DESC, descricao ASC"
    lista = con.execute(sql, params).fetchall()

    total_criticos = con.execute("SELECT COUNT(*) FROM materiais WHERE quantidade <= minimo").fetchone()[0]
    total_itens = con.execute("SELECT COUNT(*) FROM materiais").fetchone()[0]

    con.close()
    return render_template(
        "materiais.html",
        materiais=lista,
        busca=busca,
        filtro_alerta=filtro_alerta,
        total_criticos=total_criticos,
        total_itens=total_itens,
    )


@app.route("/materiais/<int:material_id>/ajustar", methods=["POST"])
def material_ajustar(material_id):
    tipo = request.form.get("tipo", "entrada")
    qtd_raw = str(request.form.get("quantidade", "0")).replace(",", ".")

    try:
        delta = abs(float(qtd_raw or 0))
    except ValueError:
        flash("Quantidade para movimentação inválida.", "erro")
        return redirect(url_for("materiais"))

    if delta == 0:
        flash("Informe uma quantidade maior que zero para movimentação.", "erro")
        return redirect(url_for("materiais"))

    con = banco.conectar()
    mat = con.execute("SELECT * FROM materiais WHERE id = ?", (material_id,)).fetchone()
    if not mat:
        con.close()
        flash("Material não encontrado.", "erro")
        return redirect(url_for("materiais"))

    saldo_atual = float(mat["quantidade"])
    if tipo == "entrada":
        novo_saldo = saldo_atual + delta
        acao_nome = "Entrada"
    elif tipo == "saida":
        novo_saldo = max(0.0, saldo_atual - delta)
        acao_nome = "Saída"
    else:  # 'definir'
        novo_saldo = delta
        acao_nome = "Ajuste de inventário"

    con.execute("UPDATE materiais SET quantidade = ? WHERE id = ?", (novo_saldo, material_id))
    con.commit()
    con.close()

    flash(f"{acao_nome} de {delta:g} {mat['unidade']} no insumo '{mat['descricao']}'. Novo saldo: {novo_saldo:g} {mat['unidade']}.", "sucesso")
    return redirect(url_for("materiais"))


@app.route("/materiais/<int:material_id>/excluir", methods=["POST"])
def material_excluir(material_id):
    con = banco.conectar()
    mat = con.execute("SELECT descricao FROM materiais WHERE id = ?", (material_id,)).fetchone()
    if not mat:
        con.close()
        flash("Material não encontrado.", "erro")
        return redirect(url_for("materiais"))

    nome_mat = mat["descricao"]
    con.execute("DELETE FROM materiais WHERE id = ?", (material_id,))
    con.commit()
    con.close()
    flash(f"Material '{nome_mat}' removido do estoque!", "sucesso")
    return redirect(url_for("materiais"))


if __name__ == "__main__":
    banco.criar_banco()
    banco.povoar()
    app.run(host="127.0.0.1", port=5055, debug=False)
