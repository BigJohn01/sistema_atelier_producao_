"""Ponto de entrada WSGI para servidores de producao (Gunicorn, Waitress, uWSGI)."""
import banco
from app import app

# Garante que o banco SQLite e tabelas existem antes de aceitar requisicoes
banco.criar_banco()
banco.povoar()

# Objeto WSGI exportado
application = app

if __name__ == "__main__":
    # Caso seja executado diretamente
    app.run()
