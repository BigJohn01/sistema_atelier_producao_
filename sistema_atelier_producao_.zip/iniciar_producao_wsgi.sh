#!/bin/bash
echo "Instalando dependencias de producao..."
pip install -r requirements.txt

echo "Iniciando servidor WSGI Gunicorn em 0.0.0.0:5055..."
gunicorn -c gunicorn.conf.py wsgi:application
