"""Configuracao de Producao do Servidor WSGI Gunicorn."""
import multiprocessing

# Endereco de escuta (todas as interfaces de rede na porta 5055 ou variavel de ambiente PORT)
bind = "0.0.0.0:5055"

# Quantidade recomendada de workers: (2 * CPUs) + 1
workers = multiprocessing.cpu_count() * 2 + 1
threads = 2
worker_class = "gthread"

# Timeouts e conexoes
timeout = 60
keepalive = 5
max_requests = 1000
max_requests_jitter = 50

# Logs
accesslog = "-"  # stdout
errorlog = "-"   # stderr
loglevel = "info"
