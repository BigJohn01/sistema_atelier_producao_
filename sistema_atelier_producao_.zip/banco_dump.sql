BEGIN TRANSACTION;
CREATE TABLE clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT,
    cidade TEXT
);
INSERT INTO "clientes" VALUES(1,'Marcos Vinicius Prado','(43) 99612-4471','Londrina - PR');
INSERT INTO "clientes" VALUES(2,'Ana Claudia Ferreira','(43) 99820-3316','Londrina - PR');
INSERT INTO "clientes" VALUES(3,'Marcenaria São José Ltda','(43) 3325-7788','Cambé - PR');
INSERT INTO "clientes" VALUES(4,'Rafael Domingues','(43) 99745-1092','Londrina - PR');
INSERT INTO "clientes" VALUES(5,'Escola Municipal Vila Nova','(43) 3372-4410','Ibiporã - PR');
INSERT INTO "clientes" VALUES(6,'Juliana Beltrão Alves','(43) 99331-6654','Londrina - PR');
CREATE TABLE historico (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ordem_id INTEGER NOT NULL,
    status TEXT NOT NULL,
    data TEXT NOT NULL,
    observacao TEXT,
    FOREIGN KEY (ordem_id) REFERENCES ordens (id)
);
INSERT INTO "historico" VALUES(1,1,'Orcamento','2026-08-12','Medidas conferidas no local');
INSERT INTO "historico" VALUES(2,1,'Aprovado','2026-08-14','Sinal de 40% recebido');
INSERT INTO "historico" VALUES(3,1,'Em producao','2026-08-19','Corte e aplainamento das peças');
INSERT INTO "historico" VALUES(4,2,'Aprovado','2026-08-06','Cliente aprovou o orçamento');
INSERT INTO "historico" VALUES(5,2,'Em producao','2026-08-11','Remoção do verniz antigo');
INSERT INTO "historico" VALUES(6,2,'Acabamento','2026-08-27','Aplicação da segunda demão');
INSERT INTO "historico" VALUES(7,3,'Em producao','2026-08-20','Usinagem no torno mecânico');
INSERT INTO "historico" VALUES(8,3,'Pronto','2026-08-27','Peças conferidas com paquímetro');
CREATE TABLE materiais (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    descricao TEXT NOT NULL,
    unidade TEXT NOT NULL,
    quantidade REAL NOT NULL,
    minimo REAL NOT NULL
);
INSERT INTO "materiais" VALUES(1,'Madeira pinus aparelhada 30x300 cm','peça',24.0,10.0);
INSERT INTO "materiais" VALUES(2,'Compensado naval 15 mm','chapa',6.0,4.0);
INSERT INTO "materiais" VALUES(3,'Tarugo de aço 1020 — 1 pol','barra',3.0,4.0);
INSERT INTO "materiais" VALUES(4,'Barra de bronze TM23 — 1.1/2 pol','barra',2.0,3.0);
INSERT INTO "materiais" VALUES(5,'Cola PVA extra para madeira','litro',9.0,5.0);
INSERT INTO "materiais" VALUES(6,'Verniz fosco poliuretano','litro',4.0,5.0);
INSERT INTO "materiais" VALUES(7,'Lixa para madeira grão 120','folha',48.0,30.0);
INSERT INTO "materiais" VALUES(8,'Parafuso chipboard 4,0 x 40 mm','cento',12.0,6.0);
CREATE TABLE ordens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    servico_id INTEGER NOT NULL,
    descricao TEXT,
    valor REAL NOT NULL,
    status TEXT NOT NULL,
    abertura TEXT NOT NULL,
    entrega TEXT,
    FOREIGN KEY (cliente_id) REFERENCES clientes (id),
    FOREIGN KEY (servico_id) REFERENCES servicos (id)
);
INSERT INTO "ordens" VALUES(1,1,1,'Mesa de 8 lugares em peroba, acabamento fosco',1980.0,'Em producao','2026-08-12','2026-09-08');
INSERT INTO "ordens" VALUES(2,2,3,'Restauração de cômoda de família',820.0,'Acabamento','2026-08-05','2026-09-02');
INSERT INTO "ordens" VALUES(3,3,5,'Lote de 4 eixos torneados para máquina de costura',840.0,'Pronto','2026-08-18','2026-08-29');
INSERT INTO "ordens" VALUES(4,4,4,'Duas prateleiras suspensas para escritório',640.0,'Aprovado','2026-08-26','2026-09-10');
INSERT INTO "ordens" VALUES(5,5,2,'Bancada de apoio para sala de informática',1240.0,'Orcamento','2026-08-28',NULL);
INSERT INTO "ordens" VALUES(6,6,7,'Luminária de mesa com base em imbuia',390.0,'Entregue','2026-07-22','2026-08-11');
INSERT INTO "ordens" VALUES(7,1,8,'Troca de chave e cabo de furadeira',120.0,'Entregue','2026-07-30','2026-08-02');
INSERT INTO "ordens" VALUES(8,4,6,'Buchas de bronze para eixo do torno',290.0,'Em producao','2026-08-24','2026-09-04');
CREATE TABLE servicos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    descricao TEXT NOT NULL,
    categoria TEXT NOT NULL,
    preco_base REAL NOT NULL,
    prazo_dias INTEGER NOT NULL
);
INSERT INTO "servicos" VALUES(1,'Mesa de jantar em madeira maciça','Marcenaria',1850.0,21);
INSERT INTO "servicos" VALUES(2,'Bancada sob medida com tampo tratado','Marcenaria',1240.0,14);
INSERT INTO "servicos" VALUES(3,'Restauração de móvel antigo','Restauração',780.0,18);
INSERT INTO "servicos" VALUES(4,'Prateleira suspensa em madeira e ferro','Marcenaria',320.0,7);
INSERT INTO "servicos" VALUES(5,'Eixo torneado em aço 1020','Usinagem',210.0,4);
INSERT INTO "servicos" VALUES(6,'Bucha de bronze usinada sob medida','Usinagem',145.0,3);
INSERT INTO "servicos" VALUES(7,'Luminária artesanal em madeira e metal','Design',390.0,9);
INSERT INTO "servicos" VALUES(8,'Reparo elétrico de ferramenta manual','Manutenção',120.0,2);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('clientes',6);
INSERT INTO "sqlite_sequence" VALUES('servicos',8);
INSERT INTO "sqlite_sequence" VALUES('materiais',8);
INSERT INTO "sqlite_sequence" VALUES('ordens',8);
INSERT INTO "sqlite_sequence" VALUES('historico',8);
COMMIT;
