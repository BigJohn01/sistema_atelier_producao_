"""Camada de dados do Sistema de Gestao de Pedidos e Producao - Atelier Nfalconeli."""
import sqlite3
from pathlib import Path

BANCO = Path(__file__).parent / "atelier.db"

ESQUEMA = """
CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT,
    cidade TEXT
);
CREATE TABLE IF NOT EXISTS servicos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    descricao TEXT NOT NULL,
    categoria TEXT NOT NULL,
    preco_base REAL NOT NULL,
    prazo_dias INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS materiais (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    descricao TEXT NOT NULL,
    unidade TEXT NOT NULL,
    quantidade REAL NOT NULL,
    minimo REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS ordens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    servico_id INTEGER NOT NULL,
    descricao TEXT,
    valor REAL NOT NULL,
    status TEXT NOT NULL,
    abertura TEXT NOT NULL,
    entrega TEXT,
    FOREIGN KEY (cliente_id) REFERENCES clientes (id),
    FOREIGN KEY (servico_id) REFERENCES servicos (id)
);
CREATE TABLE IF NOT EXISTS historico (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ordem_id INTEGER NOT NULL,
    status TEXT NOT NULL,
    data TEXT NOT NULL,
    observacao TEXT,
    FOREIGN KEY (ordem_id) REFERENCES ordens (id)
);
"""

STATUS = ["Orcamento", "Aprovado", "Em producao", "Acabamento", "Pronto", "Entregue", "Cancelado"]
STATUS_PRODUCAO = ["Orcamento", "Aprovado", "Em producao", "Acabamento", "Pronto", "Entregue"]

STATUS_ROTULO = {
    "Orcamento": "Orçamento",
    "Aprovado": "Aprovado",
    "Em producao": "Em produção",
    "Acabamento": "Acabamento",
    "Pronto": "Pronto",
    "Entregue": "Entregue",
    "Cancelado": "Cancelado",
}

STATUS_ICONE = {
    "Orcamento": "fa-file-invoice-dollar",
    "Aprovado": "fa-circle-check",
    "Em producao": "fa-hammer",
    "Acabamento": "fa-wand-magic-sparkles",
    "Pronto": "fa-box-open",
    "Entregue": "fa-truck-ramp-box",
    "Cancelado": "fa-ban",
}


def conectar():
    con = sqlite3.connect(BANCO)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def criar_banco():
    con = conectar()
    con.executescript(ESQUEMA)
    con.commit()
    con.close()


def povoar():
    """Carga inicial com os dados levantados junto ao atelier."""
    con = conectar()
    if con.execute("SELECT COUNT(*) FROM clientes").fetchone()[0]:
        con.close()
        return

    clientes = [
        ("Marcos Vinicius Prado", "(43) 99612-4471", "Londrina - PR"),
        ("Ana Claudia Ferreira", "(43) 99820-3316", "Londrina - PR"),
        ("Marcenaria São José Ltda", "(43) 3325-7788", "Cambé - PR"),
        ("Rafael Domingues", "(43) 99745-1092", "Londrina - PR"),
        ("Escola Municipal Vila Nova", "(43) 3372-4410", "Ibiporã - PR"),
        ("Juliana Beltrão Alves", "(43) 99331-6654", "Londrina - PR"),
    ]
    con.executemany("INSERT INTO clientes (nome, telefone, cidade) VALUES (?,?,?)", clientes)

    servicos = [
        ("Mesa de jantar em madeira maciça", "Marcenaria", 1850.00, 21),
        ("Bancada sob medida com tampo tratado", "Marcenaria", 1240.00, 14),
        ("Restauração de móvel antigo", "Restauração", 780.00, 18),
        ("Prateleira suspensa em madeira e ferro", "Marcenaria", 320.00, 7),
        ("Eixo torneado em aço 1020", "Usinagem", 210.00, 4),
        ("Bucha de bronze usinada sob medida", "Usinagem", 145.00, 3),
        ("Luminária artesanal em madeira e metal", "Design", 390.00, 9),
        ("Reparo elétrico de ferramenta manual", "Manutenção", 120.00, 2),
    ]
    con.executemany(
        "INSERT INTO servicos (descricao, categoria, preco_base, prazo_dias) VALUES (?,?,?,?)",
        servicos,
    )

    materiais = [
        ("Madeira pinus aparelhada 30x300 cm", "peça", 24, 10),
        ("Compensado naval 15 mm", "chapa", 6, 4),
        ("Tarugo de aço 1020 — 1 pol", "barra", 3, 4),
        ("Barra de bronze TM23 — 1.1/2 pol", "barra", 2, 3),
        ("Cola PVA extra para madeira", "litro", 9, 5),
        ("Verniz fosco poliuretano", "litro", 4, 5),
        ("Lixa para madeira grão 120", "folha", 48, 30),
        ("Parafuso chipboard 4,0 x 40 mm", "cento", 12, 6),
    ]
    con.executemany(
        "INSERT INTO materiais (descricao, unidade, quantidade, minimo) VALUES (?,?,?,?)",
        materiais,
    )

    ordens = [
        (1, 1, "Mesa de 8 lugares em peroba, acabamento fosco", 1980.00, "Em producao", "2026-08-12", "2026-09-08"),
        (2, 3, "Restauração de cômoda de família", 820.00, "Acabamento", "2026-08-05", "2026-09-02"),
        (3, 5, "Lote de 4 eixos torneados para máquina de costura", 840.00, "Pronto", "2026-08-18", "2026-08-29"),
        (4, 4, "Duas prateleiras suspensas para escritório", 640.00, "Aprovado", "2026-08-26", "2026-09-10"),
        (5, 2, "Bancada de apoio para sala de informática", 1240.00, "Orcamento", "2026-08-28", None),
        (6, 7, "Luminária de mesa com base em imbuia", 390.00, "Entregue", "2026-07-22", "2026-08-11"),
        (1, 8, "Troca de chave e cabo de furadeira", 120.00, "Entregue", "2026-07-30", "2026-08-02"),
        (4, 6, "Buchas de bronze para eixo do torno", 290.00, "Em producao", "2026-08-24", "2026-09-04"),
    ]
    con.executemany(
        "INSERT INTO ordens (cliente_id, servico_id, descricao, valor, status, abertura, entrega)"
        " VALUES (?,?,?,?,?,?,?)",
        ordens,
    )

    historico = [
        (1, "Orcamento", "2026-08-12", "Medidas conferidas no local"),
        (1, "Aprovado", "2026-08-14", "Sinal de 40% recebido"),
        (1, "Em producao", "2026-08-19", "Corte e aplainamento das peças"),
        (2, "Aprovado", "2026-08-06", "Cliente aprovou o orçamento"),
        (2, "Em producao", "2026-08-11", "Remoção do verniz antigo"),
        (2, "Acabamento", "2026-08-27", "Aplicação da segunda demão"),
        (3, "Em producao", "2026-08-20", "Usinagem no torno mecânico"),
        (3, "Pronto", "2026-08-27", "Peças conferidas com paquímetro"),
    ]
    con.executemany(
        "INSERT INTO historico (ordem_id, status, data, observacao) VALUES (?,?,?,?)",
        historico,
    )

    con.commit()
    con.close()


def indicadores():
    con = conectar()
    dados = {
        "abertas": con.execute(
            "SELECT COUNT(*) FROM ordens WHERE status NOT IN ('Entregue', 'Cancelado')"
        ).fetchone()[0],
        "producao": con.execute(
            "SELECT COUNT(*) FROM ordens WHERE status IN ('Em producao','Acabamento')"
        ).fetchone()[0],
        "prontas": con.execute("SELECT COUNT(*) FROM ordens WHERE status='Pronto'").fetchone()[0],
        "entregues": con.execute("SELECT COUNT(*) FROM ordens WHERE status='Entregue'").fetchone()[0],
        "canceladas": con.execute("SELECT COUNT(*) FROM ordens WHERE status='Cancelado'").fetchone()[0],
        "total_geral": con.execute("SELECT COUNT(*) FROM ordens").fetchone()[0],
        "carteira": con.execute(
            "SELECT COALESCE(SUM(valor),0) FROM ordens WHERE status NOT IN ('Orcamento','Entregue','Cancelado')"
        ).fetchone()[0],
        "faturamento_concluido": con.execute(
            "SELECT COALESCE(SUM(valor),0) FROM ordens WHERE status='Entregue'"
        ).fetchone()[0],
        "alerta_material": con.execute(
            "SELECT COUNT(*) FROM materiais WHERE quantidade <= minimo"
        ).fetchone()[0],
        "total_clientes": con.execute("SELECT COUNT(*) FROM clientes").fetchone()[0],
        "total_servicos": con.execute("SELECT COUNT(*) FROM servicos").fetchone()[0],
        "total_materiais": con.execute("SELECT COUNT(*) FROM materiais").fetchone()[0],
    }
    con.close()
    return dados
