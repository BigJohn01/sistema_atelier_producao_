@echo off
title Atelier Nfalconeli - Servidor WSGI Producao (Waitress)
echo ========================================================
echo   Atelier Nfalconeli - Servidor WSGI de Producao
echo ========================================================
echo.
echo Verificando dependencias WSGI (Waitress)...
pip install -r requirements.txt

echo.
echo Servidor WSGI de producao iniciando em http://0.0.0.0:5055 ...
echo Para acessar nesta maquina: http://localhost:5055
echo.
waitress-serve --listen=0.0.0.0:5055 wsgi:application
pause
